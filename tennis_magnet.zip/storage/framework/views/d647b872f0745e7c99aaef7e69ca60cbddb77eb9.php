<?php $__env->startSection('cms_content'); ?>

<div class="mb-4">
  <h1>Tennis Magnet Orders</h1>
</div>

<div class="card shadow mb-4">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>User</th>
            <th>Total</th>
            <th>Order Details</th>
            <th>Order Date</th>
          </tr>
        </thead>
        <tbody>
          
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($order->name); ?></td>
                <td>$<?php echo e($order->total); ?></td>
                <td>
                  <ul style="list-style-type:none;">
                    <?php $__currentLoopData = unserialize($order->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li>
                        <b><?php echo e($item['name']); ?></b>,<br> 
                        <b>Price: </b> $<?php echo e($item['price']); ?>,<br>  
                        <b>Quantity: </b> <?php echo e($item['quantity']); ?>

                      </li>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </td>   
                <td><?php echo e(date('d/m/Y H:i:s', strtotime($order->created_at))); ?></td>   
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/orders_index.blade.php ENDPATH**/ ?>
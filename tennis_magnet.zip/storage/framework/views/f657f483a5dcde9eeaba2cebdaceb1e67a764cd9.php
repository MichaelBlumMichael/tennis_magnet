<?php $__env->startSection('main_content'); ?>
<section class="section-conten padding-y" style="min-height:84vh">
   <div class="card mx-auto" style="max-width: 380px; margin-top:100px;">
      <div class="card-body">
         <h4 class="card-title mb-4">Log in</h4>
         <form action="" method="POST" novalidate="novalidate" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="form-group">
               <input class="form-control" name="email" id="email" placeholder="Email" type="email">
               <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
            </div>
            <div class="form-group">
               <input class="form-control" name="password" id="password" placeholder="Password" type="password">
               <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
            </div>
            <div class="form-group">
               <label class="float-left custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" checked=""> 
               </label>
            </div>
            <div class="form-group">
               <button type="submit" class="btn btn-primary btn-block"> Login  </button>
            </div>
         </form>
      </div>
   </div>
   <p class="text-center mt-4">Don't have account? <a href="<?php echo e(url('user/signup')); ?>">Sign up</a></p>
   <br><br>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/login.blade.php ENDPATH**/ ?>
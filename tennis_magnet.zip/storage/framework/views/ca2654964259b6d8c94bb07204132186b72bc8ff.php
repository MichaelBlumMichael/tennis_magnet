<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
    <h1 class="h2">Edit Menu Link</h1>
  </div>
  
  
  <div class="row">
    <div class="col-lg-6">
    <form class="add-menu-form" action="<?php echo e(url('cms/menu/'. $item->id)); ?>" method="POST" autocomplete="off" novalidate="novalidate">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="item_id" value="<?php echo e($item->id); ?>">
        <div class="form-group">
          <label for="page_name">* Page Name</label>
        <input value="<?php echo e($item->page_name); ?>" type="text" name="page_name" id="page_name" class="origin-field form-control">
        <span class="text-danger"><?php echo e($errors->first('page_name')); ?></span>
        </div>
        <div class="form-group">
          <label for="url">
            * Url
            <small><i>(Friendly url - lowercase, numbers, '-')</i></small>
          </label>
          <input value="<?php echo e($item->url); ?>" type="text" name="url" id="url" class="target-field form-control">
          <span class="text-danger"><?php echo e($errors->first('url')); ?></span>
        </div>
        <div class="form-group">
          <label for="title">* Page Title</label>
          <input value="<?php echo e($item->title); ?>" type="text" name="title" id="title" class="form-control">
          <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
        </div>
        <input type="submit" value="Save Menu" name="submit" class="btn btn-primary">
      <a href="<?php echo e(url('cms/menu')); ?>" class="btn btn-light ml-3">Cancel</a>
      </form>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/menu_edit.blade.php ENDPATH**/ ?>
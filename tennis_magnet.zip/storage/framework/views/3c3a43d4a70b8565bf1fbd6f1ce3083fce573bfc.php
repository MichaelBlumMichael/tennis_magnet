<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
    <h1 class="h2">Add  New Content</h1>
  </div>
  
  
  <div class="row">
    <div class="col-lg-6">
      <form class="edit-content-form" action="<?php echo e(url('cms/content/'. $item->id)); ?>" method="POST" autocomplete="off" novalidate="novalidate">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <div class="form-group">
          <label for="menu">* Menu Page</label>
          <select name="menu" id="menu" class="form-control">
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($item->menu_id == $menu_item->id): ?> selected="selected" <?php endif; ?> 
              value="<?php echo e($menu_item->id); ?>"><?php echo e($menu_item->page_name); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <span class="text-danger"><?php echo e($errors->first('menu')); ?></span>
        </div>
        <div class="form-group">
          <label for="title">* Content Title</label>
          <input value="<?php echo e($item->ctitle); ?>" type="text" name="title" id="title" class="form-control">
          <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
        </div>
        <div class="form-group">
          <label for="article">* Content Article</label>
        <textarea class="form-control" name="article" id="summernote" cols="30" rows="10"><?php echo e(old('article', $item->carticle)); ?></textarea>
          <span class="text-danger"><?php echo e($errors->first('article')); ?></span>
        </div>
        <input type="submit" value="Update Content" name="submit" class="btn btn-primary">
      <a href="<?php echo e(url('cms/content')); ?>" class="btn btn-light ml-3">Cancel</a>
      </form>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/content_edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('cms_content'); ?>

<div class="container-fluid">
  <div class="row">
    <div class="col-6">
      <form class="add-recommended-form" action="<?php echo e(url('cms/menu')); ?>" method="POST" autocomplete="off" novalidate="novalidate">
        <?php echo csrf_field(); ?>
      <?php if($categories->count()): ?>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card card-category">
            <div class="mt-3">
            </div>
            <div class="card-body">
            <h4 class="card-title font-weight-bold"><?php echo e($categorie->title); ?></h4>
              <ul class="list-group" style="list-style-type:none;">
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($product->categorie_id === $categorie->id): ?>
                          <li class="m-2 border-top"><?php echo e($product->ptitle); ?>

                            <button class="btn btn-primary text-white">Add to recommended</button>
                          </li>
                      <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
              <div class="col-12 text-center mt-3">
                  <p><i>No Categories Found</i></p>
              </div>
          <?php endif; ?>
      </form>
    </div>
    
    </div> <!-- row.// -->
</div>


      
    </div>
  </div>
</div>     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/recommendations_add.blade.php ENDPATH**/ ?>
<?php $__env->startSection('cms_content'); ?>

<div class="container">
    <form enctype="multipart/form-data" class="add-categorie-form" action="<?php echo e(url('cms/recomp/')); ?>" method="POST" autocomplete="off" novalidate="novalidate">
            <?php echo csrf_field(); ?>
       <h1>Recommended Products </h1> 

       <div class="form-group">
           <label for="product">Product</label>
           <select name="product" id="product" class="form-control">
            <?php $__currentLoopData = $recommended_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option id="product-drop" value=<?php echo e($product->id); ?> selected="selected"><?php echo e($product->ptitle); ?></option> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
           <span class="text-danger"><?php echo e($errors->first('product')); ?></span>
       </div>

       <input type="submit" value="Add to Recommentations" name="submit" class="btn btn-primary mt-4 send-recommended">
          <a href="<?php echo e(url('cms/dashboard')); ?>" class="btn btn-light mt-4">Cancel</a>
          <span class="text-danger"><?php echo e($errors->first('product')); ?></span>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/recommendation_index.blade.php ENDPATH**/ ?>
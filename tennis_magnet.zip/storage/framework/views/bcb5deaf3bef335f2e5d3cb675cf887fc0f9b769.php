<?php $__env->startSection('main_content'); ?>
<section class="section-content padding-y">
   <div class="container">
      <nav class="row">
         <?php if($categories->count()): ?>
         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-md-3">
            <div class="card card-category">
               <div class="img-wrap d-flex justify-content-center mt-3" style="background: #ffffff">
                  <img class="rounded category-image" src="<?php echo e(asset('images/demo/'. $categorie->image)); ?>">
               </div>
               <div class="card-body">
                  <h4 class="card-title text-center"><a href="<?php echo e(url('shop/' . $categorie->url)); ?>"><?php echo e($categorie->title); ?></a></h4>
                  <ul class="list-menu text-center">
                     <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($product->categorie_id === $categorie->id): ?>
                     <li><?php echo e($product->ptitle); ?></li>
                     <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
               </div>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php else: ?>
         <div class="col-12 text-center mt-3">
            <p><i>No Categories Found</i></p>
         </div>
         <?php endif; ?>
      </nav>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/categories.blade.php ENDPATH**/ ?>
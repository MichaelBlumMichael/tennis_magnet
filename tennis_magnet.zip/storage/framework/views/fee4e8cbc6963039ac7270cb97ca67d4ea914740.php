<?php $__env->startSection('cms_content'); ?>

<div class="row">
  <div class="col-lg-6">
  <form enctype="multipart/form-data" class="add-categorie-form" action="<?php echo e(url('cms/recomendations-add-product')); ?>" method="POST" autocomplete="off" novalidate="novalidate">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="selected-categorie">* Category</label>
          <select class="form-control selected-categorie" name="category" id="categorie-id">
            <option value="">Choose Category...</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option <?php if(old('categorie') == $categorie->id): ?> selected="selected" <?php endif; ?>
                value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <input type="submit" value="Choose Product" name="submit" class="btn btn-primary mt-4">
          <a href="<?php echo e(url('cms/recommendations')); ?>" class="btn btn-light mt-4">Cancel</a>
        </form>
        <span class="text-danger"><?php echo e($errors->first('category')); ?></span>
      </div>
    </form>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/recommendations_choose_categorie.blade.php ENDPATH**/ ?>
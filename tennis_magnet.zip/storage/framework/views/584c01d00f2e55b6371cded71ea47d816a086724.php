<?php $__env->startSection('cms_content'); ?>

<div class="container">
    <form enctype="multipart/form-data" class="add-categorie-form" action="<?php echo e(url('cms/recom-category/')); ?>" method="POST" autocomplete="off" novalidate="novalidate">
            <?php echo csrf_field(); ?>
       <h1>Choose Category</h1> 

       <div class="form-group">
        <label for="category">Category</label>
        <select name="category" id="category" class="form-control">
            <option value="">Select Category...</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
       <input type="submit" value="Get Products" name="submit" class="btn btn-primary mt-4 send-recommended">
          <a href="<?php echo e(url('cms/dashboard')); ?>" class="btn btn-light mt-4">Cancel</a>
          <span class="text-danger"><?php echo e($errors->first('category')); ?></span>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/recommendation_choose_category.blade.php ENDPATH**/ ?>
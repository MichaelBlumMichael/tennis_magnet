<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
    <h1 class="h2">Are you sure you want to delete this item?</h1>
  </div>
  
  <div class="row">
    <div class="col-lg-6">
    <form class="add-content-form" action="<?php echo e(url('cms/content/' . $item_id)); ?>" method="POST" autocomplete="off" novalidate="novalidate">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('DELETE')); ?>

        <input type="submit" value="Delete" name="submit" class="btn btn-danger">
      <a href="<?php echo e(url('cms/content')); ?>" class="btn btn-light ml-3">Cancel</a>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/content_delete.blade.php ENDPATH**/ ?>
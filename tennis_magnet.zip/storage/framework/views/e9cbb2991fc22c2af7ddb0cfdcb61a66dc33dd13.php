<?php $__env->startSection('cms_content'); ?>



<div class="row">
  <div class="col-lg-6">
  <form enctype="multipart/form-data" class="add-categorie-form" action="<?php echo e(url('cms/categories')); ?>" method="POST" autocomplete="off" novalidate="novalidate">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="title">* Categoriy Title</label>
      <input value="<?php echo e(old('title')); ?>" type="text" name="title" id="title" class="origin-field form-control">
      <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
      </div>
      <div class="form-group">
        <label for="url">
          * Url
          <small><i>(Friendly url - lowercase, numbers, '-')</i></small>
        </label>
        <input value="<?php echo e(old('url')); ?>" type="text" name="url" id="url" class="target-field form-control">
        <span class="text-danger"><?php echo e($errors->first('url')); ?></span>
      </div>
      <div class="form-group">
        <label for="article">* Category Description</label>
      <textarea id="summernote" class="form-control" name="description" id="article" cols="30" rows="10"><?php echo e(old('description')); ?></textarea>
        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
      </div>
      <div class="form-group">
        <label for="image">Upload Category Picture
          <small><i>(Optional):</i></small>
        </label>
      </div>
      <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
        </div>
        <div class="custom-file">
          <input name="image" type="file" class="image-upload custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
        </div>
      </div>
      <div class="form-group">
        <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
      </div>
      <input type="submit" value="Save Category" name="submit" class="btn btn-primary">
    <a href="<?php echo e(url('cms/categories')); ?>" class="btn btn-light ml-3">Cancel</a>
    </form>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/categories_create.blade.php ENDPATH**/ ?>
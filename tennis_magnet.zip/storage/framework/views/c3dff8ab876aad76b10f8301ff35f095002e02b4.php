<?php $__env->startSection('cms_content'); ?>
<div class="mb-4">
  <h3>Recommended Products</h3>
</div>
<div class="row">
  <div class="col-12">
    <p>
      <a class="btn btn-primary" href="<?php echo e(url('cms/recom-categroies')); ?>">Add New Recommendation</a>
    </p>
  </div>
</div>

<div class="card shadow mb-4">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Product Title</th>
            <th>Product Image</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($recommendation->ptitle); ?></td>  
            <td>
                <img class="img-thumbnail" width="50" src="<?php echo e(asset('images/demo/' . $recommendation->pimage)); ?>" alt="">
            </td>
            <td class="text-center">
            <a class="ml-2 text-danger" title="Delete Menu" href="<?php echo e(url('cms/recom-delete/' . $recommendation->rid)); ?>">Delete</a>             
            </td> 
          </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/recommendation_table.blade.php ENDPATH**/ ?>
<?php $__env->startSection('main_content'); ?>
<section class="section-content padding-y">
    <div class="container">
    <nav class="row">
        <aside class="col-md-3">
            <nav class="list-group">
                <p class="list-group-item" href="page-profile-main.html"><b>Categories</b></p>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="list-group-item" href="<?php echo e(url('shop/' . $categorie->url)); ?>"><?php echo e($categorie->title); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <p class="list-group-item sidebar-category mb-4"></p>
            </nav>
        </aside>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 d-flex">
            <div class=" d-flex align-items-stretch mb-4"> 
                <div class="card recprod">
                  <div class="img-wrap d-flex justify-content-center mt-3" style="background: #ffff">
                    <img src="<?php echo e(asset('images/demo/' . $product->pimage)); ?>" class="product-img card-img-top" alt="product-image">
                </div>
                  <div class="card-body">
                  <h4 class="card-title text-center">
                      <a href="<?php echo e(url('shop/' . $product->url . '/' .  $product->purl)); ?>"><?php echo e($product->ptitle); ?></a></h4>
                  <div class="card-body">
                    <p><?php echo $product->particle; ?></p>
                    <p><b>Price: </b>$<?php echo e($product->price); ?></p>
                    <p>
                    <?php if(!Cart::get($product->id)): ?>
                        <button data-pid="<?php echo e($product->id); ?>" class="btn btn-success add-to-cart-btn">Add To Cart</button>
                    <?php else: ?>
                        <button class="btn btn-success add-to-cart-btn" disabled="disabled">In Cart</button>  
                    <?php endif; ?>
                    <a href="<?php echo e(url('shop/' . $product->url . '/' .  $product->purl)); ?>" class="btn btn-primary ml-2">More Details</a>
                    </p>
                </div>
                  </div>
                </div>
            </div>
        </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav> 
        </div> 
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/products.blade.php ENDPATH**/ ?>
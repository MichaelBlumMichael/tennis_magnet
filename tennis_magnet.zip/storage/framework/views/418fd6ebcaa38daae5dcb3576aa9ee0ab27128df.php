<?php $__env->startSection('cms_content'); ?>

<div>
  <h3 class="mb-4">Content Control Panel</h3>
</div>
<div class="row">
  <div class="col-12">
    <p>
      <a class="btn btn-primary" href="<?php echo e(url('cms/content/create')); ?>">Add Content</a>
    </p>
  </div>
</div>

<div class="card shadow mb-4">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Content title</th>
            <th>Page Name</th>
            <th>Last update</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($item->ctitle); ?></td> 
          <td><?php echo e($menu->find($item->menu_id)->page_name); ?></td> 
            <td><?php echo e(date('d/m/Y', strtotime($item->updated_at))); ?></td> 
            <td class="text-center">
            <a title="Edit Content" href="<?php echo e(url('cms/content/'.$item->id.'/edit')); ?>">Edit</a> 
            <a class="ml-2 text-danger" title="Delete Content" href="<?php echo e(url('cms/content/' . $item->id)); ?>">Delete</a>             
            </td> 
          </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cms/content_index.blade.php ENDPATH**/ ?>
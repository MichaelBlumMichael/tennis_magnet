<?php $__env->startSection('main_content'); ?>
<section class="section-content padding-y">
   <div class="container">
      <div class="row">
         <main class="col-md-9">
            <div class="card">
               <?php if(! Cart::isEmpty()): ?>
               <table class="table table-borderless table-shopping-cart">
                  <thead class="text-muted">
                     <tr class="small text-uppercase">
                        <th scope="col">Product</th>
                        <th scope="col" width="120">Quantity</th>
                        <th scope="col" width="120">Price</th>
                        <th scope="col" width="120">Sub-Total</th>
                        <th scope="col" class="text-right" width="200"> </th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td>
                           <figure class="itemside">
                              <div class="aside"><img src="<?php echo e(asset('images/demo/' . $item['attributes']['image'])); ?>" class="img-sm"></div>
                              <figcaption class="info">
                                 <a href="#" class="  text-dark"><?php echo e($item['name']); ?></a>
                              </figcaption>
                           </figure>
                        </td>
                        <td> 
                           <select data-pid="<?php echo e($item['id']); ?>" class="form-control product-quantity">
                           <?php for($x = 1; $x < $max_product_quantity; $x++): ?>   
                           <option <?php if($x == $item['quantity']): ?> selected="selected" <?php endif; ?> value="<?php echo e($x); ?>"><?php echo e($x); ?></option>
                           <?php endfor; ?>
                           </select>
                        </td>
                        <td>
                           <div class="price-wrap"> 
                              <var class="price">$<?php echo e($item['price']); ?></var> 
                           </div>
                        </td>
                        <td>
                           <div class="price-wrap"> 
                              <var class="price">$<?php echo e($item['quantity'] * $item['price']); ?></var> 
                           </div>
                        </td>
                        <td class="text-right"> 
                           <a data-original-title="Save to Wishlist" title="" href="" class="btn btn-light" data-toggle="tooltip"> <i class="fa fa-heart"></i></a> 
                           <a href="<?php echo e(url('shop/cart?removeItem=' . $item['id'])); ?>" class="btn btn-light"> Remove</a>
                        </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
               <div class="card-body border-top">
                  <a href="<?php echo e(url('shop/clear-cart')); ?>" class="btn btn-light float-md-right"> Clear Cart <i class="fas fa-times"></i></a>
                  <a href="<?php echo e(url('shop')); ?>" class="btn btn-light"> <i class="fa fa-chevron-left"></i> Continue shopping </a>
               </div>
            </div>
            <?php else: ?>
            <p class="text-center display-4 p-4"><i>You do not have any items in cart...</i></p>
            <div class="card-body border-top">
               <a href="<?php echo e(url('shop')); ?>" class="btn btn-primary"> <i class="fa fa-chevron-left"></i> Continue shopping </a>
            </div>
            <?php endif; ?>
            <div class="alert alert-success mt-3">
               <p class="icontext"><i class="icon text-success fa fa-truck"></i> Free Delivery within 1-2 weeks</p>
            </div>
         </main>
         <aside class="col-md-3">
            <div class="card">
               <div class="card-body">
                  <dl class="dlist-align">
                     <dt>Total: </dt>
                     <dd class="text-right  h5"><strong>$<?php echo e(Cart::getTotal()); ?></strong></dd>
                  </dl>
                  <hr>
                  <p class="text-center mb-3">
                     <img src="<?php echo e(asset('images/misc/payments.png')); ?>" height="26">
                  </p>
                  <a href="<?php echo e(url('shop/checkout')); ?>" class="btn btn-primary d-flex justify-content-center"> Make Purchase </i> </a>
               </div>
            </div>
         </aside>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tennis_magnet\resources\views/cart.blade.php ENDPATH**/ ?>